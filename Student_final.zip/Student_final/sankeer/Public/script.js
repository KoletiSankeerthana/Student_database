// JavaScript for handling the temporary password modal
const lecturerLink = document.getElementById('lecturer-link');
const modal = document.getElementById('password-modal');
const modalPassword = document.getElementById('modal-password');
const modalSubmit = document.getElementById('modal-submit');
const errorMessage = document.getElementById('error-message');
const closeButton = document.querySelector('.close-button');

// Event listener for Lecturer Login
lecturerLink.addEventListener('click', () => {
  modalPassword.value = ''; // Clear any previous input
  errorMessage.textContent = ''; // Clear error message
  modal.style.display = 'flex'; // Show the modal
});

// Close the modal
closeButton.addEventListener('click', () => {
  modal.style.display = 'none'; // Hide the modal
});

// Submit button logic for validating temporary password
modalSubmit.addEventListener('click', async () => {
  const password = modalPassword.value;

  if (!password) {
    errorMessage.textContent = 'Please enter a password';
    return;
  }

  try {
    const response = await fetch('/validate-temp-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    });

    if (response.ok) {
      const result = await response.json();
      window.location.href = result.redirectUrl; // Redirect to lecturer login
    } else {
      const result = await response.json();
      errorMessage.textContent = result.message || 'Incorrect Temporary Password!';
    }
  } catch (error) {
    console.error('Error:', error);
    errorMessage.textContent = 'Unable to process your request!';
  }
});

// Handle student login
const studentForm = document.getElementById('student-form');
studentForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const username = document.getElementById('student-username').value;
  const password = document.getElementById('student-password').value;
  const errorMessage = document.getElementById('student-error-message');

  if (!username || !password) {
    errorMessage.textContent = 'Please fill in all fields';
    return;
  }

  try {
    const response = await fetch('/validate-student-login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
      const result = await response.json();
      window.location.href = result.redirectUrl; // Redirect to student dashboard
    } else {
      const result = await response.json();
      errorMessage.textContent = result.message || 'Invalid credentials!';
    }
  } catch (error) {
    console.error('Error:', error);
    errorMessage.textContent = 'Unable to process your request!';
  }
});

// Handle lecturer login
const lecturerForm = document.getElementById('lecturer-form');
lecturerForm.addEventListener('submit', async (event) => {
  event.preventDefault();  // Prevent default form submission
  console.log('Form submitted');  // Log form submission

  const username = document.getElementById('lecturer-username').value;
  const password = document.getElementById('lecturer-password').value;
  const errorMessage = document.getElementById('lecturer-error-message');

  // Clear previous error message
  errorMessage.textContent = '';

  if (!username || !password) {
    errorMessage.textContent = 'Please fill in all fields';
    return;
  }

  try {
    console.log('Sending request to validate lecturer login');  // Log before making request
    const response = await fetch('/validate-lecturer-login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
      const result = await response.json();
      console.log('Login successful:', result);  // Log successful login
      window.location.href = result.redirectUrl; // Redirect to lecturer dashboard
    } else {
      const result = await response.json();
      console.log('Login failed:', result);  // Log failed login
      errorMessage.textContent = result.message || 'Invalid credentials!';
    }
  } catch (error) {
    console.error('Error:', error);  // Log error
    errorMessage.textContent = 'Unable to process your request!';
  }
});
