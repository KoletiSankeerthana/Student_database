const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

const app = express();
const PORT = 3000;

// PostgreSQL Configuration
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'Student_Management',
  password: '2850',
  port: 5432,
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files (CSS, JS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Initial Temporary Password for Lecturer
const TEMP_PASSWORD = 'lecturer123'; // Temporary password for lecturer access

// Route for index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route for lecturer login page
app.get('/lecturer-login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'lecturer-login.html'));
});

// Route for student dashboard
app.get('/student-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'student-dashboard.html'));
});

// Route for lecturer dashboard
app.get('/lecturer-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'lecturer-dashboard.html'));
});

// Validate temporary password for lecturer
app.post('/validate-temp-password', (req, res) => {
  const { password } = req.body;

  if (password === TEMP_PASSWORD) {
    return res.status(200).json({ redirectUrl: '/lecturer-login' });
  }

  res.status(401).json({ message: 'Incorrect Temporary Password!' });
});

// Validate lecturer login credentials
app.post('/validate-lecturer-login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const result = await pool.query('SELECT * FROM lecturers WHERE username = $1', [username]);

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Lecturer not found' });
    }

    const lecturer = result.rows[0];
    if (lecturer.password === password) {
      return res.status(200).json({ redirectUrl: `/lecturer-dashboard?username=${username}` });
    } else {
      return res.status(401).json({ message: 'Incorrect login credentials!' });
    }
  } catch (err) {
    console.error('Error validating lecturer credentials:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Validate student login credentials
app.post('/validate-student-login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const result = await pool.query('SELECT * FROM students WHERE username = $1', [username]);

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Student not found' });
    }

    const student = result.rows[0];
    if (student.password === password) {
      // Redirect with username as a query parameter
      return res.status(200).json({ redirectUrl: `/student-dashboard?username=${username}` });
    } else {
      return res.status(401).json({ message: 'Incorrect login credentials!' });
    }
  } catch (err) {
    console.error('Error validating student credentials:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Endpoint to fetch student data for the dashboard
app.get('/student-dashboard-data', async (req, res) => {
  const { username } = req.query;

  try {
    // Fetch student details
    const studentResult = await pool.query('SELECT * FROM students WHERE username = $1', [username]);

    if (studentResult.rows.length === 0) {
      return res.status(404).json({ message: 'Student not found' });
    }

    const student = studentResult.rows[0];

    // Fetch courses and grades
    const coursesResult = await pool.query(`
      SELECT 
        c.course_name, 
        e.grade, 
        c.credits, 
        s.semester_name AS semester
      FROM enrollments e
      JOIN courses c ON e.course_id = c.course_id
      JOIN semesters s ON e.semester_id = s.semester_id
      WHERE e.student_id = $1
    `, [student.student_id]);
    

    // Fetch the CGPA
    const cgpaResult = await pool.query('SELECT calculate_cgpa($1) AS cgpa', [student.student_id]);

    // Log the raw CGPA result for debugging
    console.log('CGPA Result:', cgpaResult.rows[0]?.cgpa);

    let cgpa = cgpaResult.rows[0]?.cgpa;

    // Ensure cgpa is a valid number, and format it to 2 decimal places
    if (isNaN(cgpa) || cgpa === null) {
      cgpa = 0; // Default to 0 if CGPA is invalid
    } else {
      cgpa = (Number(cgpa)).toFixed(2); // Ensure it's a valid number and format to two decimal places
    }

    // Log the formatted CGPA for debugging
    console.log('Formatted CGPA:', cgpa);

    res.json({
      first_name: student.first_name,
      last_name: student.last_name,
      cgpa: cgpa, // Send formatted CGPA
      courses: coursesResult.rows,
    });





  } catch (err) {
    console.error('Error fetching student data:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Endpoint to fetch students enrolled in courses taught by the lecturer

app.get('/lecturer-dashboard-data', async (req, res) => {
  const { username } = req.query;

  try {
    // Fetch lecturer details
    const lecturerResult = await pool.query('SELECT * FROM lecturers WHERE username = $1', [username]);
    
    if (lecturerResult.rows.length === 0) {
      return res.status(404).json({ message: 'Lecturer not found' });
    }

    const lecturer = lecturerResult.rows[0];

    // Fetch students enrolled in courses taught by the lecturer, including marks and CGPA
    const studentsResult = await pool.query(`
      SELECT 
        s.student_id,
        s.first_name,
        s.last_name,
        c.course_name,
        se.semester_name,
        e.grade,
        e.marks_obtained,
        c.credits,
        se.cgpa -- Assuming CGPA is stored in the semesters table
      FROM enrollments e
      JOIN students s ON e.student_id = s.student_id
      JOIN courses c ON e.course_id = c.course_id
      JOIN semesters se ON e.semester_id = se.semester_id
      WHERE c.lecturer_id = $1
    `, [lecturer.lecturer_id]);

    // Log the result for debugging
    console.log('Students data:', studentsResult.rows);

    // If CGPA is not in the `semesters` table, calculate it or handle the case accordingly.
    for (let student of studentsResult.rows) {
      if (!student.cgpa) {
        // If CGPA is not found in the semesters table, calculate it from the grades and credits
        const cgpaResult = await pool.query('SELECT calculate_cgpa($1) AS cgpa', [student.student_id]);
        student.cgpa = cgpaResult.rows[0]?.cgpa || 0;  // Use 0 if CGPA calculation is missing
      }
    }

    // Log after CGPA calculation
    console.log('Students with CGPA:', studentsResult.rows);

    res.json({ students: studentsResult.rows });

  } catch (err) {
    console.error('Error fetching lecturer data:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});
// Update marks for a student in a specific course
app.post('/update-marks', async (req, res) => {
  const { student_id, marks, course_name } = req.body;

  try {
    // Update marks in the enrollments table
    const result = await pool.query(`
      UPDATE enrollments
      SET marks_obtained = $1
      WHERE student_id = $2 AND course_id = (
        SELECT course_id FROM courses WHERE course_name = $3 LIMIT 1
      )
      RETURNING *
    `, [marks, student_id, course_name]);

    if (result.rowCount > 0) {
      // After updating marks, recalculate the CGPA
      const cgpaResult = await pool.query('SELECT calculate_cgpa($1) AS cgpa', [student_id]);
      const cgpa = cgpaResult.rows[0]?.cgpa || 0;  // Default to 0 if CGPA is missing

      // Return success and updated CGPA
      res.status(200).json({
        message: 'Marks updated successfully',
        cgpa: cgpa.toFixed(2), // Send the formatted CGPA
      });
    } else {
      res.status(404).json({ message: 'Course or student not found' });
    }
  } catch (err) {
    console.error('Error updating marks:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});


// Remove a student from the system
app.post('/remove-student', async (req, res) => {
  const { student_id } = req.body;

  try {
    // Remove the student from the enrollments table
    await pool.query('DELETE FROM enrollments WHERE student_id = $1', [student_id]);

    // Remove the student from the students table
    const result = await pool.query('DELETE FROM students WHERE student_id = $1 RETURNING *', [student_id]);

    if (result.rowCount > 0) {
      res.status(200).json({ message: 'Student removed successfully' });
    } else {
      res.status(404).json({ message: 'Student not found' });
    }
  } catch (err) {
    console.error('Error removing student:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});



// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port http://localhost:${PORT}`);
});
